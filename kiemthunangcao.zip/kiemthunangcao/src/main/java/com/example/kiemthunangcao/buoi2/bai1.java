package com.example.kiemthunangcao.buoi2;

public class bai1 {
    public  int tích2songuyen(int a ,int b){
        return a*b;
    }


}
