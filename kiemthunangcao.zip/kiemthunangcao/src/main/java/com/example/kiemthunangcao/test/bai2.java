package com.example.kiemthunangcao.test;

public class bai2 {
    public int multiply(int a, int b) {
        return a * b;
    }
}
