package com.example.kiemthunangcao.test;

public class bai1 {
public int add(int a , int b){
    return a - b;
}


}
