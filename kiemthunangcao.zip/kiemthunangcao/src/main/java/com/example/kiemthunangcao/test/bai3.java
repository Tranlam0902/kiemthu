package com.example.kiemthunangcao.test;

public class bai3 {
    public double divide(double a, double b) {
        if (b == 0) throw new ArithmeticException("Cannot divide by zero");
        return a / b;
    }

}
