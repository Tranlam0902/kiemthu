import com.example.kiemthunangcao.test.bai1;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;

public class test {
    bai1 bai1 = new bai1();

    @Test
    void testSubtractWithPositiveNumbers() {
        assertEquals(5, bai1.add(10, 5)); // Biên trong vùng hợp lệ
    }

    @Test
    void testSubtractWithNegativeNumbers() {
        assertEquals(-3, bai1.add(-5, -2)); // Trường hợp cả hai số âm
    }

    @Test
    void testSubtractWithZero() {
        assertEquals(10, bai1.add(10, 0)); // Một số là 0
    }

    @Test
    void testSubtractResultingInZero() {
        assertEquals(0, bai1.add(5, 5)); // Hiệu bằng 0
    }

    @Test
    void testSubtractWithMixedSignNumbers() {
        assertEquals(15, bai1.add(10, -5)); // Số dương trừ số âm
    }

}
