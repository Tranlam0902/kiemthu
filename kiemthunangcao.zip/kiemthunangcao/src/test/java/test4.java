import com.example.kiemthunangcao.test.bai4;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
public class test4 {
    bai4 bai4 = new bai4();
    @Test
    void testAverageWithPositiveNumbers() {
        assertEquals(3.0, bai4.average(new int[]{2, 3, 4}), 0.001); // Dãy số dương
    }

    @Test
    void testAverageWithNegativeNumbers() {
        assertEquals(-2.0, bai4.average(new int[]{-3, -2, -1}), 0.001); // Dãy số âm
    }

    @Test
    void testAverageWithMixedNumbers() {
        assertEquals(0.0, bai4.average(new int[]{-3, 3, 0}), 0.001); // Dãy số trộn
    }

    @Test
    void testAverageWithSingleNumber() {
        assertEquals(5.0, bai4.average(new int[]{5}), 0.001); // Một phần tử
    }

    @Test
    void testAverageWithEmptyArray() {
        assertThrows(IllegalArgumentException.class, () -> bai4.average(new int[]{})); // Mảng rỗng
    }



}
