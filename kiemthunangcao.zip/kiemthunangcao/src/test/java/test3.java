import com.example.kiemthunangcao.test.bai3;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
public class test3 {
    bai3 bai3 = new bai3();

    @Test
    void testDivideWithPositiveNumbers() {
        assertEquals(2.0, bai3.divide(10, 5), 0.001); // Hai số dương
    }

    @Test
    void testDivideWithNegativeNumbers() {
        assertEquals(1.5, bai3.divide(-3, -2), 0.001); // Hai số âm
    }

    @Test
    void testDivideWithMixedSignNumbers() {
        assertEquals(-2.5, bai3.divide(5, -2), 0.001); // Số dương chia số âm
    }

    @Test
    void testDivideByOne() {
        assertEquals(10.0, bai3.divide(10, 1), 0.001); // Chia cho 1
    }

    @Test
    void testDivideByZero() {
        assertThrows(ArithmeticException.class, () -> bai3.divide(10, 0)); // Chia cho 0
    }

}
