package buoi2test;
import com.example.kiemthunangcao.buoi2.bai2;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
public class test2 {
bai2 bai2 = new bai2();
    @Test
    public void testDividePositiveNumbers() {
        assertEquals(2, bai2.divide(10, 5)); // 1
    }

    @Test
    public void testDivideNegativeNumbers() {
        assertEquals(3, bai2.divide(-9, -3)); // 2
    }

    @Test
    public void testDividePositiveByNegative() {
        assertEquals(-5, bai2.divide(10, -2)); // 3
    }

    @Test
    public void testDivideNegativeByPositive() {
        assertEquals(-4, bai2.divide(-12, 3)); // 4
    }

    @Test
    public void testDivideByOne() {
        assertEquals(7, bai2.divide(7, 1)); // 5
    }

    @Test
    public void testDivideByItself() {
        assertEquals(1, bai2.divide(9, 9)); // 6
    }

    @Test
    public void testDivideByZero() {
        bai2.divide(10, 0); // 7
    }

    @Test
    public void testDivideZeroByNumber() {
        assertEquals(0, bai2.divide(0, 5)); // 8
    }

    @Test
    public void testDivideLargeNumbers() {
        assertEquals(1,bai2.divide(Integer.MAX_VALUE, Integer.MAX_VALUE)); // 9
    }

    @Test
    public void testDivideSmallNumbers() {
        assertEquals(2, bai2.divide(4, 2)); // 10
    }


}
