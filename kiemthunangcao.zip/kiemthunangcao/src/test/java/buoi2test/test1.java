package buoi2test;
import com.example.kiemthunangcao.buoi2.bai1;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
public class test1 {
bai1 bai1 = new bai1();
    @Test
    public void testMultiplyPositiveNumbers() {
        assertEquals(20, bai1.tích2songuyen(4, 5)); // 1
    }

    @Test
    public void testMultiplyNegativeNumbers() {
        assertEquals(15, bai1.tích2songuyen(-3, -5)); // 2
    }

    @Test
    public void testMultiplyWithNegativeAndPositive() {
        assertEquals(-12, bai1.tích2songuyen(-3, 4)); // 3
    }

    @Test
    public void testMultiplyWithZero() {
        assertEquals(0, bai1.tích2songuyen(0, 5)); // 4
    }

    @Test
    public void testMultiplyWithOne() {
        assertEquals(7, bai1.tích2songuyen(1, 7)); // 5
    }

    @Test
    public void testMultiplyLargeNumbers() {
        assertEquals(1000000, bai1.tích2songuyen(1000, 1000)); // 6
    }

    @Test
    public void testMultiplyWithNegativeOne() {
        assertEquals(-9, bai1.tích2songuyen(-1, 9)); // 7
    }

    @Test
    public void testMultiplyWithMinValue() {
        assertEquals(0, bai1.tích2songuyen(Integer.MIN_VALUE, 0)); // 8
    }

    @Test
    public void testMultiplyWithMaxValue() {
        assertEquals(Integer.MAX_VALUE, bai1.tích2songuyen(1, Integer.MAX_VALUE)); // 9
    }

    @Test
    public void testMultiplyCommutativeProperty() {
        assertEquals(bai1.tích2songuyen(3, 7), bai1.tích2songuyen(7, 3)); // 10
    }
}
