import com.example.kiemthunangcao.test.bai2;
import org.junit.jupiter.api.Test;

import static org.junit.jupiter.api.Assertions.*;
public class test2 {
  bai2 bai2 = new bai2();
    @Test
    void testMultiplyWithPositiveNumbers() {
        assertEquals(50, bai2.multiply(10, 5)); // Hai số dương
    }

    @Test
    void testMultiplyWithNegativeNumbers() {
        assertEquals(6, bai2.multiply(-3, -2)); // Hai số âm
    }

    @Test
    void testMultiplyWithZero() {
        assertEquals(0, bai2.multiply(10, 0)); // Một số là 0
    }

    @Test
    void testMultiplyWithMixedSignNumbers() {
        assertEquals(-15, bai2.multiply(3, -5)); // Số dương nhân số âm
    }

    @Test
    void testMultiplyWithLargeNumbers() {
        assertEquals(1000000, bai2.multiply(1000, 1000)); // Biên lớn
    }
}
